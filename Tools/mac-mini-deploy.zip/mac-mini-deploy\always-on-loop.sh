#!/bin/bash
# Life-OS Always-On Loop — Runs on Mac Mini 24/7
# AutoResearch + Verifier in a continuous Karpathy loop
#
# Usage: nohup bash always-on-loop.sh &
# Or install as launchd service (setup.sh does this)

LIFEOS_DIR="$HOME/life-os"
LOG_DIR="$LIFEOS_DIR/briefings"
CYCLE=0
MAX_BUDGET="5.00"
SLEEP_BETWEEN=1800  # 30 minutes between cycles

mkdir -p "$LOG_DIR"

echo "$(date): Always-on loop starting" >> "$LOG_DIR/always-on.log"

while true; do
    CYCLE=$((CYCLE + 1))
    TIMESTAMP=$(date '+%Y-%m-%d_%H%M')
    echo "$(date): === CYCLE $CYCLE ===" >> "$LOG_DIR/always-on.log"

    # --- AUTORESEARCH ---
    echo "$(date): Running autoresearch agent..." >> "$LOG_DIR/always-on.log"

    claude -p "You are the autoresearch agent. Read .claude/agents/autoresearch.md for your full protocol. Read METRICS.md for current score. Run your loop: AUDIT the system (check Task Scheduler, processes, logs, MCP), IDENTIFY the single biggest gap, EXPERIMENT (fix it), VERIFY (prove it works), SCORE (update METRICS.md). One improvement this cycle. Be honest in scoring." \
        --allowedTools 'Bash(*)' 'Read(*)' 'Write(*)' 'Edit(*)' 'Glob(*)' 'Grep(*)' 'Agent(*)' \
        --max-turns 30 \
        --max-budget-usd "$MAX_BUDGET" \
        --output-file "$LOG_DIR/autoresearch-$TIMESTAMP.log" \
        2>> "$LOG_DIR/always-on.log" || true

    echo "$(date): Autoresearch complete. Running verifier..." >> "$LOG_DIR/always-on.log"

    # --- VERIFIER ---
    claude -p "You are the verifier agent. Read .claude/agents/verifier.md for your protocol. Read the latest autoresearch log at briefings/autoresearch-$TIMESTAMP.log (or if not found, read METRICS.md for the latest claims). Verify every claim. Check actual files, processes, logs. Adjust the Life-OS Rating if needed. Fix anything you find broken." \
        --allowedTools 'Bash(*)' 'Read(*)' 'Write(*)' 'Edit(*)' 'Glob(*)' 'Grep(*)' \
        --max-turns 20 \
        --max-budget-usd "$MAX_BUDGET" \
        --output-file "$LOG_DIR/verifier-$TIMESTAMP.log" \
        2>> "$LOG_DIR/always-on.log" || true

    echo "$(date): Cycle $CYCLE complete. Sleeping ${SLEEP_BETWEEN}s..." >> "$LOG_DIR/always-on.log"

    # Sleep between cycles (30 min default)
    # Shorter at night (2am-6am) for more overnight progress
    HOUR=$(date +%H)
    if [ "$HOUR" -ge 2 ] && [ "$HOUR" -lt 6 ]; then
        sleep 900  # 15 min cycles overnight
    else
        sleep $SLEEP_BETWEEN
    fi
done
